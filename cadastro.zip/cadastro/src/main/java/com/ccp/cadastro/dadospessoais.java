/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.ccp.cadastro;
import java.util.Scanner;

/**
 *
 * @author autologon
 */
public class dadospessoais {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner leia = new Scanner(System.in);
      System.out.print("digite seu nome :");
      String nome = leia.next();
      System.out.print("digite sua idade: ");
      int idade = leia.nextInt();
      System.out.print("digite seu hobby: ");
      String hobby = leia.next();
      System.out.println("o nome digitado e: "+nome+" e sua idade e: "+idade+" o seu hobby e: "+hobby);
    }
    
}
